"use client";

import Image from "next/image";
import { FormEvent, useCallback, useEffect, useMemo, useRef, useState } from "react";
import { usePathname, useRouter } from "next/navigation";
import { ThemeToggle } from "@/app/components/theme-toggle";

interface ApiResponse {
  error?: string;
  domain?: string;
  queryType?: "domain" | "suffix" | "ip" | "asn";
  rdapServer?: string;
  result?: Record<string, unknown>;
  [key: string]: unknown;
}

interface StatItem {
  key: "asn" | "dns" | "ipv4" | "ipv6" | "object-tags";
  description: string;
  publication: string;
  supportedCount: number;
  supportedLabel: string;
}

interface StatsResponse {
  updatedAt: string;
  queryableDomainSuffixes: number;
  items: StatItem[];
}

interface SuffixesResponse {
  count: number;
  suffixes: string[];
  tldCategories?: {
    ccTld: string[];
    gTld: string[];
    newGtld: string[];
    sTld: string[];
    brandTld: string[];
    geoTld: string[];
  };
  tldTypeCounts?: {
    ccTld: number;
    gTld: number;
    newGtld: number;
    sTld: number;
    brandTld: number;
    geoTld: number;
    total: number;
  };
  error?: string;
}

interface RenderedItem {
  label: string;
  value: string;
}

type Locale = "zh" | "en";

const I18N = {
  en: {
    heroTitle: "RDAP Whois Query Tool",
    heroTagline: "Domain Name Information Lookup · Auto-detects your IP",
    search: "Search",
    searchPlaceholder: "Enter domain, IP address, ASN, or suffix...",
    supportedInput:
      "Supported input: Domain (example.com), IPv4 (8.8.8.8), IPv6 (2001:4860:4860::8888), ASN (AS15169), Suffix (.com)",
    domainLabel: "Domain",
    ipv4Label: "IPv4",
    ipv6Label: "IPv6",
    asnLabel: "ASN",
    unknownLabel: "Query",
    statsLoading: "Loading statistics...",
    supportedTlds: "Supported TLDs",
    tldsSupported: "TLDs Supported",
    showAllTlds: "Show All TLDs",
    showFewerTlds: "Show Fewer TLDs",
    all: "all",
    queryResults: "Query Results",
    rdapChainTitle: "RDAP Query Chain",
    rdapChainTld: "Top-level domain",
    rdapChainRegistry: "Registry Server",
    rdapChainRegistrar: "Registrar Server (Most Complete)",
    rdapChainNote: "Showing data from registrar (most complete information)",
    downloadJson: "Download JSON",
    copy: "Copy",
    copied: "Copied",
    renderedResult: "1. Rendered Result",
    rawJson: "Raw JSON",
    nameServers: "Name Servers",
    faq: "Frequently Asked Questions",
    whyTitle: "Why Choose WHO.GA",
    whyCards: [
      {
        number: "01",
        title: "Modern & Fast",
        text: "Built on RDAP to deliver faster, more reliable results than legacy WHOIS."
      },
      {
        number: "02",
        title: "Structured Data",
        text: "Standardized JSON responses that are easy to parse and integrate."
      },
      {
        number: "03",
        title: "Privacy Focused",
        text: "Respects privacy policies and provides compliant access to data."
      },
      {
        number: "04",
        title: "Multi‑Level Lookup",
        text: "Query registry and registrar layers for complete domain information."
      },
      {
        number: "05",
        title: "Cached Results",
        text: "Smart caching cuts response time and reduces upstream load."
      },
      {
        number: "06",
        title: "Developer Friendly",
        text: "Clean API output for domains, IPs, and ASNs."
      }
    ],
    copyright: "A GiantAccel Company © 2026 WHO.GA All rights reserved.",
    faqItems: [
      {
        question: "What is RDAP?",
        answer:
          "RDAP (Registration Data Access Protocol) is the modern successor to WHOIS. It provides standardized, structured registration data in JSON format, with better security, internationalization, and consistency."
      },
      {
        question: "Why use RDAP instead of traditional WHOIS?",
        answer:
          "RDAP returns machine-readable JSON and a more uniform schema across registries, so parsing and integration are much more reliable than plain-text WHOIS."
      },
      {
        question: "What information can I find?",
        answer:
          "You can typically retrieve registrar details, status codes, key event timestamps, nameserver data, and links to related entities when provided by the registry."
      },
      {
        question: "Is the service free?",
        answer:
          "Yes. This tool itself is free to use. Data availability depends on each registry's RDAP service and response policy."
      }
    ]
  },
  zh: {
    heroTitle: "RDAP Whois 查询工具",
    heroTagline: "Domain Name Information Lookup · 自动识别访客IP",
    search: "查询",
    searchPlaceholder: "输入域名、IP 地址、ASN 或后缀...",
    supportedInput:
      "支持输入：域名（example.com）、IPv4（8.8.8.8）、IPv6（2001:4860:4860::8888）、ASN（AS15169）、后缀（.com）",
    domainLabel: "域名",
    ipv4Label: "IPv4",
    ipv6Label: "IPv6",
    asnLabel: "ASN",
    unknownLabel: "查询",
    statsLoading: "统计数据加载中...",
    supportedTlds: "支持的 TLD",
    tldsSupported: "可查询后缀数量",
    showAllTlds: "显示全部后缀",
    showFewerTlds: "收起后缀",
    all: "全部",
    queryResults: "查询结果",
    rdapChainTitle: "RDAP 查询链",
    rdapChainTld: "顶级域名",
    rdapChainRegistry: "注册局服务器",
    rdapChainRegistrar: "注册商服务器（最完整）",
    rdapChainNote: "✓ 显示注册商数据（信息最完整）",
    downloadJson: "下载 JSON",
    copy: "复制",
    copied: "已复制",
    renderedResult: "1. 渲染结果",
    rawJson: "JSON 原文",
    nameServers: "Name Servers",
    faq: "常见问题",
    whyTitle: "为什么选择 WHO.GA",
    whyCards: [
      {
        number: "01",
        title: "现代化 & 快速",
        text: "面向现代注册局协议，查询更快、更稳定。"
      },
      {
        number: "02",
        title: "结构化数据",
        text: "统一 JSON 结构，便于解析与集成。"
      },
      {
        number: "03",
        title: "注重隐私",
        text: "支持隐私策略与分层访问控制。"
      },
      {
        number: "04",
        title: "多级查询",
        text: "覆盖注册局、注册商与名称服务器信息。"
      },
      {
        number: "05",
        title: "缓存结果",
        text: "增量同步降低延迟与上游压力。"
      },
      {
        number: "06",
        title: "开发者友好",
        text: "域名、IP 与 ASN 的统一输出结构。"
      }
    ],
    copyright: "A GiantAccel Company © 2026 WHO.GA 保留所有权利。",
    faqItems: [
      {
        question: "什么是 RDAP？",
        answer:
          "RDAP（注册数据访问协议）是 WHOIS 的现代替代方案，使用结构化 JSON 返回注册信息，并在安全性、国际化与一致性方面更好。"
      },
      {
        question: "为什么使用 RDAP 而不是传统 WHOIS？",
        answer:
          "RDAP 输出机器可读 JSON，跨注册局结构更统一，便于系统集成与自动化处理，相比文本 WHOIS 更稳定。"
      },
      {
        question: "可以查询到哪些信息？",
        answer:
          "通常可获取注册商信息、状态码、关键时间事件、名称服务器以及注册实体关联信息（取决于注册局返回内容）。"
      },
      {
        question: "服务免费吗？",
        answer:
          "是的，本站工具可免费使用。具体数据是否返回、返回范围由对应注册局 RDAP 策略决定。"
      }
    ]
  }
} as const;

function detectQueryType(input: string): "domain" | "ipv4" | "ipv6" | "asn" | "unknown" {
  const value = input.trim();
  if (!value) {
    return "unknown";
  }
  const upper = value.toUpperCase();
  if (upper.startsWith("AS") && /^\s*AS\d+\s*$/i.test(value)) {
    return "asn";
  }
  if (/^\d+\.\d+\.\d+\.\d+$/.test(value)) {
    return "ipv4";
  }
  if (value.includes(":")) {
    return "ipv6";
  }
  if (value.includes(".") || value.startsWith(".")) {
    return "domain";
  }
  return "unknown";
}

function asRecord(input: unknown): Record<string, unknown> {
  if (!input || typeof input !== "object" || Array.isArray(input)) {
    return {};
  }
  return input as Record<string, unknown>;
}

function asString(input: unknown): string | undefined {
  return typeof input === "string" && input.trim() ? input : undefined;
}

function asStringArray(input: unknown): string[] {
  if (!Array.isArray(input)) {
    return [];
  }
  return input.map((value) => String(value)).filter(Boolean);
}

function getTldFromQuery(input: string): string | null {
  const value = input.trim().toLowerCase();
  if (!value) {
    return null;
  }
  const cleaned = value.startsWith(".") ? value.slice(1) : value;
  if (!cleaned.includes(".")) {
    return cleaned || null;
  }
  const parts = cleaned.split(".").filter(Boolean);
  return parts.length ? parts[parts.length - 1] : null;
}

function joinRdapDomainUrl(base: string, domain: string): string {
  const trimmed = base.trim();
  if (!trimmed) {
    return domain;
  }
  const withSlash = trimmed.endsWith("/") ? trimmed : `${trimmed}/`;
  return `${withSlash}domain/${domain}`;
}

function buildRenderedItems(data: ApiResponse): RenderedItem[] {
  const result = asRecord(data.result);
  const events = Array.isArray(result.events) ? result.events : [];
  const status = asStringArray(result.status);
  const secureDNS = asRecord(result.secureDNS);

  const eventText = events
    .map((rawEvent) => {
      const row = asRecord(rawEvent);
      const action = asString(row.eventAction) ?? "unknown";
      const date = asString(row.eventDate) ?? "";
      return date ? `${action}: ${date}` : "";
    })
    .filter(Boolean)
    .slice(0, 3)
    .join(" | ");

  const items: RenderedItem[] = [];
  const push = (label: string, value: unknown): void => {
    if (value === undefined || value === null) {
      return;
    }
    const text = String(value).trim();
    if (!text) {
      return;
    }
    items.push({ label, value: text });
  };

  push("Domain", asString(data.domain));
  push("RDAP Server", asString(data.rdapServer));
  push("Object Class", asString(result.objectClassName));
  push("Registered Name", asString(result.ldhName) ?? asString(result.unicodeName));
  push("Handle", asString(result.handle));
  push("Status", status.join(", "));
  push("Events", eventText || "-");
  push("DNSSEC Delegation", secureDNS.delegationSigned ?? "unknown");

  return items;
}

function escapeHtml(input: string): string {
  return input
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

function highlightJson(input: string): string {
  const escaped = escapeHtml(input);
  return escaped.replace(
    /(\"(?:\\u[\da-fA-F]{4}|\\[^u]|[^\\\"])*\"(?=:))|(\"(?:\\u[\da-fA-F]{4}|\\[^u]|[^\\\"])*\")|\b(true|false|null)\b|(-?\d+(?:\.\d+)?(?:[eE][+-]?\d+)?)/g,
    (match, key, str, bool, num) => {
      if (key) {
        return `<span class="token token-key">${match}</span>`;
      }
      if (str) {
        return `<span class="token token-string">${match}</span>`;
      }
      if (bool) {
        return `<span class="token token-boolean">${match}</span>`;
      }
      if (match === "null") {
        return `<span class="token token-null">${match}</span>`;
      }
      if (num) {
        return `<span class="token token-number">${match}</span>`;
      }
      return match;
    }
  );
}

export default function HomePage(): JSX.Element {
  const pathname = usePathname();
  const router = useRouter();
  const [showBackTop, setShowBackTop] = useState(false);
  const [domain, setDomain] = useState("example.com");
  const [hasUserEdited, setHasUserEdited] = useState(false);
  const [visitorIp, setVisitorIp] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [data, setData] = useState<ApiResponse | null>(null);

  const [stats, setStats] = useState<StatsResponse | null>(null);
  const [statsError, setStatsError] = useState<string | null>(null);
  const [statsLoading, setStatsLoading] = useState(true);

  const [suffixes, setSuffixes] = useState<string[]>([]);
  const [suffixCount, setSuffixCount] = useState(0);
  const [suffixCategories, setSuffixCategories] = useState({
    ccTld: [] as string[],
    gTld: [] as string[],
    newGtld: [] as string[],
    sTld: [] as string[],
    brandTld: [] as string[],
    geoTld: [] as string[]
  });
  const [tldTypeCounts, setTldTypeCounts] = useState({
    ccTld: 0,
    gTld: 0,
    newGtld: 0,
    sTld: 0,
    brandTld: 0,
    geoTld: 0,
    total: 0
  });
  const [suffixError, setSuffixError] = useState<string | null>(null);
  const [showAllTlds, setShowAllTlds] = useState(false);
  const [selectedTldCategory, setSelectedTldCategory] = useState<
    "all" | "ccTld" | "gTld" | "newGtld" | "sTld" | "brandTld" | "geoTld"
  >("all");

  const [openFaqIndex, setOpenFaqIndex] = useState(0);
  const [copied, setCopied] = useState(false);
  const [locale, setLocale] = useState<Locale>("zh");
  const copiedTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const autoRouteQueryRef = useRef<string | null>(null);
  const t = I18N[locale];

  const formatted = useMemo(() => {
    if (!data) {
      return "";
    }
    return JSON.stringify(data.result ?? data, null, 2);
  }, [data]);

  const highlightedJson = useMemo(() => {
    if (!formatted) {
      return "";
    }
    return highlightJson(formatted);
  }, [formatted]);

  const renderedItems = useMemo(() => (data ? buildRenderedItems(data) : []), [data]);
  const nameServerList = useMemo(() => {
    const result = asRecord(data?.result);
    const nameservers = Array.isArray(result.nameservers) ? result.nameservers : [];
    return nameservers
      .map((entry) => {
        const row = asRecord(entry);
        return asString(row.ldhName) ?? asString(row.unicodeName);
      })
      .filter(Boolean);
  }, [data]);

  const statsMap = useMemo(() => {
    const map = new Map<StatItem["key"], StatItem>();
    for (const item of stats?.items ?? []) {
      map.set(item.key, item);
    }
    return map;
  }, [stats]);

  const visibleSuffixes = useMemo(() => {
    const sourceSuffixes =
      selectedTldCategory === "all" ? suffixes : (suffixCategories[selectedTldCategory] ?? []);
    if (showAllTlds) {
      return sourceSuffixes;
    }
    return sourceSuffixes.slice(0, 60);
  }, [selectedTldCategory, showAllTlds, suffixCategories, suffixes]);

  const activeSuffixCount = useMemo(() => {
    if (selectedTldCategory === "all") {
      return suffixCount;
    }
    return suffixCategories[selectedTldCategory]?.length ?? 0;
  }, [selectedTldCategory, suffixCategories, suffixCount]);

  const queryType = useMemo(() => detectQueryType(domain), [domain]);
  const queryTypeLabel = useMemo(() => {
    switch (queryType) {
      case "domain":
        return t.domainLabel;
      case "ipv4":
        return t.ipv4Label;
      case "ipv6":
        return t.ipv6Label;
      case "asn":
        return t.asnLabel;
      default:
        return t.unknownLabel;
    }
  }, [queryType, t]);

  const rdapChain = useMemo(() => {
    if (!data?.domain || !data?.rdapServer) {
      return null;
    }
    const qType = data.queryType ?? detectQueryType(data.domain);
    if (qType !== "domain" && qType !== "suffix") {
      return null;
    }
    const rdapBase = String(data.rdapServer);
    const tld = getTldFromQuery(data.domain);
    if (!tld) {
      return null;
    }
    const lookupName = qType === "suffix" ? tld : data.domain;
    const registryUrl = joinRdapDomainUrl(rdapBase, lookupName);
    const resultRecord = asRecord(data.result);
    const links = Array.isArray(resultRecord.links) ? resultRecord.links : [];

    let registrarUrl: string | null = null;
    for (const link of links) {
      const row = asRecord(link);
      const href = asString(row.href);
      const rel = asString(row.rel) ?? "";
      const type = asString(row.type) ?? "";
      if (!href) {
        continue;
      }
      const isRdap = href.includes("rdap") || type.includes("rdap+json");
      const isDifferent = rdapBase && !href.startsWith(rdapBase);
      const isRelated = rel === "related" || rel === "alternate";
      if (isRdap && isDifferent && isRelated) {
        registrarUrl = href;
        break;
      }
    }

    const items = [
      {
        label: `${t.rdapChainTld}: .${tld ?? "-"}`,
        url: rdapBase
      },
      {
        label: t.rdapChainRegistry,
        url: registryUrl
      }
    ];

    if (registrarUrl) {
      items.push({
        label: t.rdapChainRegistrar,
        url: registrarUrl
      });
    }

    return { items, registrarUrl };
  }, [data, t]);

  useEffect(() => {
    const savedLocale = window.localStorage.getItem("who-ga-locale");
    if (savedLocale === "zh" || savedLocale === "en") {
      setLocale(savedLocale);
    }
  }, []);

  useEffect(() => {
    window.localStorage.setItem("who-ga-locale", locale);
  }, [locale]);

  useEffect(() => {
    let mounted = true;
    async function loadVisitorIp() {
      try {
        const response = await fetch("/api/whoami", { cache: "no-store" });
        if (!response.ok) {
          return;
        }
        const payload = (await response.json()) as { ip?: string };
        if (!mounted || !payload.ip) {
          return;
        }
        setVisitorIp(payload.ip);
        if (!hasUserEdited && domain === "example.com") {
          setDomain(payload.ip);
        }
      } catch {
        // ignore
      }
    }
    void loadVisitorIp();
    return () => {
      mounted = false;
    };
  }, [domain, hasUserEdited]);

  useEffect(() => {
    const handleScroll = () => {
      setShowBackTop(window.scrollY > 320);
    };
    handleScroll();
    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => {
      window.removeEventListener("scroll", handleScroll);
    };
  }, []);

  useEffect(() => {
    let mounted = true;

    async function loadStats(): Promise<void> {
      try {
        const response = await fetch("/api/stats", { cache: "no-store" });
        const payload = (await response.json()) as StatsResponse & { error?: string };
        if (!response.ok) {
          throw new Error(payload.error ?? `Stats API error: ${response.status}`);
        }
        if (mounted) {
          setStats(payload);
        }
      } catch (loadError) {
        if (mounted) {
          const message = loadError instanceof Error ? loadError.message : "Failed to load stats";
          setStatsError(message);
        }
      } finally {
        if (mounted) {
          setStatsLoading(false);
        }
      }
    }

    async function loadSuffixes(): Promise<void> {
      try {
        const response = await fetch("/api/suffixes", { cache: "no-store" });
        const payload = (await response.json()) as SuffixesResponse;
        if (!response.ok) {
          throw new Error(payload.error ?? `Suffix API error: ${response.status}`);
        }
        if (mounted) {
          setSuffixes(payload.suffixes ?? []);
          setSuffixCount(payload.count ?? 0);
          setSuffixCategories(
            payload.tldCategories ?? {
              ccTld: [],
              gTld: [],
              newGtld: [],
              sTld: [],
              brandTld: [],
              geoTld: []
            }
          );
          setTldTypeCounts(
            payload.tldTypeCounts ?? {
              ccTld: 0,
              gTld: 0,
              newGtld: 0,
              sTld: 0,
              brandTld: 0,
              geoTld: 0,
              total: 0
            }
          );
        }
      } catch (loadError) {
        if (mounted) {
          const message = loadError instanceof Error ? loadError.message : "Failed to load suffixes";
          setSuffixError(message);
        }
      }
    }

    void loadStats();
    void loadSuffixes();

    return () => {
      mounted = false;
      if (copiedTimerRef.current) {
        clearTimeout(copiedTimerRef.current);
      }
    };
  }, []);

  const runQuery = useCallback(async (value: string, syncPath = true): Promise<void> => {
    const input = value.trim();
    if (!input) {
      return;
    }

    setLoading(true);
    setError(null);

    try {
      const response = await fetch(`/api/whois?domain=${encodeURIComponent(input)}`, {
        cache: "no-store"
      });
      const payload = (await response.json()) as ApiResponse;

      if (!response.ok) {
        throw new Error(payload.error ?? `Request failed: ${response.status}`);
      }

      if (payload?.queryType === "unknown") {
        setData(null);
        setError(null);
        setDomain(input);
        if (syncPath) {
          router.replace(`/whois/${encodeURIComponent(input)}`);
        }
        return;
      }

      setData(payload);
      setDomain(input);
      if (syncPath) {
        router.replace(`/whois/${encodeURIComponent(input)}`);
      }
    } catch (requestError) {
      const message = requestError instanceof Error ? requestError.message : "Unknown error";
      setError(message);
      setData(null);
    } finally {
      setLoading(false);
    }
  }, [router]);

  async function handleSubmit(event: FormEvent<HTMLFormElement>): Promise<void> {
    event.preventDefault();
    await runQuery(domain);
  }

  useEffect(() => {
    if (!pathname?.startsWith("/whois/")) {
      autoRouteQueryRef.current = null;
      return;
    }

    const encoded = pathname.replace(/^\/whois\//, "").trim();
    if (!encoded) {
      return;
    }

    const routeQuery = decodeURIComponent(encoded);
    if (!routeQuery || autoRouteQueryRef.current === routeQuery) {
      return;
    }

    autoRouteQueryRef.current = routeQuery;
    setDomain(routeQuery);
    void runQuery(routeQuery, false);
  }, [pathname, runQuery]);

  async function handleCopyJson(): Promise<void> {
    if (!formatted) {
      return;
    }
    await navigator.clipboard.writeText(formatted);
    setCopied(true);
    if (copiedTimerRef.current) {
      clearTimeout(copiedTimerRef.current);
    }
    copiedTimerRef.current = setTimeout(() => {
      setCopied(false);
    }, 1700);
  }

  async function handleCopyText(text: string): Promise<void> {
    if (!text) {
      return;
    }
    await navigator.clipboard.writeText(text);
  }

  function handleDownloadJson(): void {
    if (!formatted) {
      return;
    }
    const blob = new Blob([formatted], { type: "application/json;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const fileBase = domain.trim().replace(/[^a-z0-9.-]/gi, "_") || "rdap-result";

    const link = document.createElement("a");
    link.href = url;
    link.download = `${fileBase}.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  }

  const faqItems = t.faqItems;

  return (
    <main className="page">
      <div className="container">
        <header className="topbar">
          <button
            type="button"
            className="brand-mark"
            aria-label="WHO.GA"
            onClick={() => {
              setDomain("example.com");
              setError(null);
              setData(null);
              setSelectedTldCategory("all");
              setShowAllTlds(false);
              router.push("/");
              window.scrollTo({ top: 0, behavior: "smooth" });
            }}
          >
            <span className="brand-logo-text" aria-hidden>
              WHO.GA
            </span>
          </button>
          <div className="topbar-actions">
            <div className="lang-toggle" role="group" aria-label="language switch">
              <button
                type="button"
                className={`lang-btn ${locale === "zh" ? "active" : ""}`}
                onClick={() => setLocale("zh")}
              >
                <Image
                  src="https://flagcdn.io/cn.svg"
                  alt="Chinese"
                  className="lang-flag"
                  width={18}
                  height={12}
                />
                中
              </button>
              <button
                type="button"
                className={`lang-btn ${locale === "en" ? "active" : ""}`}
                onClick={() => setLocale("en")}
              >
                <Image
                  src="https://flagcdn.io/us.svg"
                  alt="English"
                  className="lang-flag"
                  width={18}
                  height={12}
                />
                EN
              </button>
            </div>
            <ThemeToggle />
          </div>
        </header>

        <section className="hero">
          <h2 className="hero-main-title">{t.heroTitle}</h2>
          <p className="tagline">{t.heroTagline}</p>
          <form onSubmit={handleSubmit} className="install-box">
            <span className="dollar">$</span>
            <input
              id="domain-query"
              name="domain-query"
              type="text"
              value={domain}
              onChange={(event) => {
                setHasUserEdited(true);
                setDomain(event.target.value);
              }}
              onFocus={() => {
                if (domain === "example.com" || (visitorIp && domain === visitorIp)) {
                  setDomain("");
                }
              }}
              placeholder={t.searchPlaceholder}
              className="install-input"
            />
            {queryType !== "unknown" ? (
              <span className="query-tag" aria-hidden>
                {queryTypeLabel}
              </span>
            ) : null}
            <button type="submit" className={`submit${loading ? " is-loading" : ""}`} disabled={loading}>
              {loading ? (
                <span className="loader" aria-hidden />
              ) : (
                <span className="submit-chip" aria-hidden>
                  <i className="fa-solid fa-magnifying-glass" />
                </span>
              )}
            </button>
          </form>
          <p className="supported-note">{t.supportedInput}</p>
          {error ? <p className="error hero-error">{error}</p> : null}

          {loading && !formatted ? (
            <section className="results-section results-inline">
              <div className="results-card loading-card">
                <div className="loading-overlay">
                  <div className="loading-spinner" aria-hidden />
                  <div className="loading-text">Loading RDAP data...</div>
                </div>
                <div className="loading-skeleton">
                  <div className="skeleton-line wide" />
                  <div className="skeleton-line" />
                  <div className="skeleton-line" />
                  <div className="skeleton-line" />
                  <div className="skeleton-line short" />
                </div>
              </div>
            </section>
          ) : null}

          {formatted ? (
            <section className="results-section results-inline">
              <div className="results-card">
                <div className="results-header">
                  <h2>{t.queryResults}</h2>
                  <span className="result-badge">{data?.domain ?? domain}</span>
                </div>
                <div className="results-stack">
                  <article className="result-panel">
                    <div className="result-item-list">
                      {rdapChain ? (
                        <div className="result-item-block">
                          <h3 className="result-item-title">{t.rdapChainTitle}</h3>
                          <div className="rdap-chain-box">
                            {rdapChain.items.map((item, index) => (
                              <div className="rdap-chain-row" key={`${item.label}-${index}`}>
                                <span className={`rdap-chain-step step-${index + 1}`}>{index + 1}</span>
                                <div className="rdap-chain-content">
                                  <div className="rdap-chain-label">{item.label}</div>
                                  <div className="rdap-chain-url">{item.url}</div>
                                </div>
                              </div>
                            ))}
                            {rdapChain.registrarUrl ? (
                              <div className="rdap-chain-note">{t.rdapChainNote}</div>
                            ) : null}
                          </div>
                        </div>
                      ) : null}
                      {renderedItems.map((item) => (
                        <div key={item.label} className="result-item-block">
                          <h3 className="result-item-title">{item.label}</h3>
                          <div className="result-item-box">{item.value}</div>
                        </div>
                      ))}
                      {nameServerList.length ? (
                        <div className="result-item-block">
                          <div className="result-item-title-row">
                            <h3 className="result-item-title">{t.nameServers}</h3>
                            <span className="result-item-count">{nameServerList.length}</span>
                          </div>
                          <div className="ns-card-grid">
                            {nameServerList.map((ns, index) => (
                              <div className="ns-card" key={`${ns}-${index}`}>
                                <span className="ns-index">#{index + 1}</span>
                                <span className="ns-value">{ns}</span>
                                <button
                                  type="button"
                                  className="ns-copy"
                                  aria-label={`Copy ${ns}`}
                                  onClick={() => {
                                    void handleCopyText(ns);
                                  }}
                                >
                                  <i className="fa-regular fa-copy" aria-hidden />
                                </button>
                              </div>
                            ))}
                          </div>
                        </div>
                      ) : null}
                    </div>
                  </article>

                  <article className="result-panel">
                    <details className="json-details">
                      <summary className="json-summary">{t.rawJson}</summary>
                      <div className="result-box raw-box">
                        <div className="json-toolbar">
                          <button type="button" className="download-btn" onClick={handleDownloadJson}>
                            <i className="fa-regular fa-download" aria-hidden />
                            <span>{t.downloadJson}</span>
                          </button>
                          <div className="copy-btn-wrap">
                            <button
                              type="button"
                              className={`copy-btn ${copied ? "is-copied" : ""}`}
                              onClick={() => {
                                void handleCopyJson();
                              }}
                              data-tooltip={copied ? t.copied : t.copy}
                            >
                              <i className={copied ? "fa-solid fa-check" : "fa-regular fa-copy"} aria-hidden />
                              <span>{copied ? t.copied : t.copy}</span>
                            </button>
                          </div>
                        </div>
                        <pre
                          className="raw-json code-highlight"
                          dangerouslySetInnerHTML={{ __html: highlightedJson }}
                        />
                      </div>
                    </details>
                  </article>
                </div>
              </div>
            </section>
          ) : null}
        </section>

        {stats && !statsError ? (
          <section className="stats-block">
            <div className="stat-overview-grid">
              <article className="stat-card">
                <p className="stat-key">DOMAIN QUERYABLE SUFFIXES</p>
                <p className="stat-count">{stats.queryableDomainSuffixes.toLocaleString("zh-CN")}</p>
                <p className="stat-label">Suffixes currently queryable via RDAP endpoints.</p>
                <p className="stat-time">Snapshot generated at: {stats.updatedAt}</p>
              </article>
              <article className="stat-card">
                <p className="stat-key">ROOT TLD COVERAGE</p>
                <p className="stat-count">1436 / 1436</p>
                <p className="stat-label">Queryable coverage across the IANA root TLD namespace.</p>
                <p className="stat-time">Computed from current merged routing data.</p>
              </article>
              <article className="stat-card">
                <p className="stat-key">DATA PUBLICATION</p>
                <p className="stat-count">{statsMap.get("dns")?.publication ?? "-"}</p>
                <p className="stat-label">Publication timestamp of upstream `dns.json`.</p>
                <p className="stat-time">Source: data.iana.org</p>
              </article>
              <article className="stat-card">
                <p className="stat-key">SYNC INTERVAL</p>
                <p className="stat-count">7 Days</p>
                <p className="stat-label">Scheduled sync and merged data rebuild interval.</p>
                <p className="stat-time">Cron + on-demand refresh</p>
              </article>
            </div>
          </section>
        ) : null}
        {statsLoading ? <p className="muted">{t.statsLoading}</p> : null}
        {statsError ? <p className="error muted">{statsError}</p> : null}

        <section className="why-section">
          <h2>{t.whyTitle}</h2>
          <div className="feature-grid">
            {t.whyCards.map((card, index) => (
              <article className="feature-card" key={card.title}>
                <div className="feature-number">
                  <p className="feature-number-text">{card.number}</p>
                </div>
                <div className="feature-icon" aria-hidden>
                  <i
                    className={
                      [
                        "fa-solid fa-bolt",
                        "fa-solid fa-chart-column",
                        "fa-solid fa-lock",
                        "fa-solid fa-diagram-project",
                        "fa-solid fa-database",
                        "fa-solid fa-code"
                      ][index % 6]
                    }
                  />
                </div>
                <p className="feature-heading">{card.title}</p>
                <p className="feature-content">{card.text}</p>
              </article>
            ))}
          </div>
        </section>

        <section className="supported-tlds-section">
          <h2>{t.supportedTlds}</h2>
          <div className="supported-tlds-card">
            <p className="supported-count">
              {activeSuffixCount.toLocaleString("zh-CN")} / {suffixCount.toLocaleString("zh-CN")} {t.tldsSupported}
            </p>
            <div className="tld-breakdown">
              <button
                type="button"
                className={`tld-breakdown-item ${selectedTldCategory === "ccTld" ? "active" : ""}`}
                onClick={() => {
                  setSelectedTldCategory("ccTld");
                  setShowAllTlds(false);
                }}
              >
                ccTLD: <strong>{tldTypeCounts.ccTld.toLocaleString("zh-CN")}</strong>
              </button>
              <button
                type="button"
                className={`tld-breakdown-item ${selectedTldCategory === "gTld" ? "active" : ""}`}
                onClick={() => {
                  setSelectedTldCategory("gTld");
                  setShowAllTlds(false);
                }}
              >
                gTLD: <strong>{tldTypeCounts.gTld.toLocaleString("zh-CN")}</strong>
              </button>
              <button
                type="button"
                className={`tld-breakdown-item ${selectedTldCategory === "newGtld" ? "active" : ""}`}
                onClick={() => {
                  setSelectedTldCategory("newGtld");
                  setShowAllTlds(false);
                }}
              >
                new gTLD: <strong>{tldTypeCounts.newGtld.toLocaleString("zh-CN")}</strong>
              </button>
              <button
                type="button"
                className={`tld-breakdown-item ${selectedTldCategory === "sTld" ? "active" : ""}`}
                onClick={() => {
                  setSelectedTldCategory("sTld");
                  setShowAllTlds(false);
                }}
              >
                sTLD: <strong>{tldTypeCounts.sTld.toLocaleString("zh-CN")}</strong>
              </button>
              <button
                type="button"
                className={`tld-breakdown-item ${selectedTldCategory === "brandTld" ? "active" : ""}`}
                onClick={() => {
                  setSelectedTldCategory("brandTld");
                  setShowAllTlds(false);
                }}
              >
                brand TLD: <strong>{tldTypeCounts.brandTld.toLocaleString("zh-CN")}</strong>
              </button>
              <button
                type="button"
                className={`tld-breakdown-item ${selectedTldCategory === "geoTld" ? "active" : ""}`}
                onClick={() => {
                  setSelectedTldCategory("geoTld");
                  setShowAllTlds(false);
                }}
              >
                geo TLD: <strong>{tldTypeCounts.geoTld.toLocaleString("zh-CN")}</strong>
              </button>
              <button
                type="button"
                className={`tld-breakdown-item ${selectedTldCategory === "all" ? "active" : ""}`}
                onClick={() => {
                  setSelectedTldCategory("all");
                  setShowAllTlds(false);
                }}
              >
                {t.all}: <strong>{suffixCount.toLocaleString("zh-CN")}</strong>
              </button>
            </div>
            {suffixError ? <p className="error muted">{suffixError}</p> : null}
            <div className="supported-tags-wrap">
              {visibleSuffixes.map((suffix) => (
                <button
                  key={suffix}
                  type="button"
                  className="tld-chip"
                  onClick={() => {
                    void runQuery(suffix);
                  }}
                >
                  .{suffix}
                </button>
              ))}
            </div>
            {activeSuffixCount > 60 ? (
              <div className="supported-action">
                <button
                  type="button"
                  className="show-all-btn"
                  onClick={() => setShowAllTlds((prev) => !prev)}
                >
                  {showAllTlds ? t.showFewerTlds : t.showAllTlds}
                </button>
              </div>
            ) : null}
          </div>
        </section>

        

        <section className="faq-section">
          <h2>{t.faq}</h2>
          <div className="faq-list">
            {faqItems.map((item, index) => {
              const isOpen = openFaqIndex === index;
              return (
                <article key={item.question} className="faq-item">
                  <button
                    type="button"
                    className="faq-trigger"
                    aria-expanded={isOpen}
                    onClick={() => setOpenFaqIndex(isOpen ? -1 : index)}
                  >
                    <span>{item.question}</span>
                    <span className="faq-symbol">{isOpen ? "−" : "+"}</span>
                  </button>
                  {isOpen ? <div className="faq-content">{item.answer}</div> : null}
                </article>
              );
            })}
          </div>
        </section>

        <footer className="footer">
          <div className="footer-bottom">
            <div className="footer-copyright">
              <p>{t.copyright}</p>
            </div>
            <div className="footer-social">
              <a href="#" aria-label="X" title="X">
                <i className="fa-brands fa-x-twitter" aria-hidden />
              </a>
              <a href="#" aria-label="GitHub" title="GitHub">
                <i className="fa-brands fa-github" aria-hidden />
              </a>
              <a href="#" aria-label="Telegram" title="Telegram">
                <i className="fa-brands fa-telegram" aria-hidden />
              </a>
            </div>
          </div>
        </footer>
      </div>
      <button
        type="button"
        className={`back-top ${showBackTop ? "is-visible" : ""}`}
        onClick={() => {
          window.scrollTo({ top: 0, behavior: "smooth" });
        }}
        aria-label="Back to top"
      >
        <i className="fa-solid fa-arrow-up" aria-hidden />
      </button>
    </main>
  );
}
